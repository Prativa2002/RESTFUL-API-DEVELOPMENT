# Library API - RESTful CRUD System

This is a simple RESTful API for managing a library system built with Node.js and Express.

## 📌 Features
- View all books
- View a single book by ID
- Add a new book
- Update an existing book
- Delete a book

## 🚀 Run Instructions

1. **Install Node.js** if not already installed.
2. In the project directory, run:
   ```bash
   npm install express
   node server.js
   ```

3. API will be available at: `http://localhost:3000/api/books`

## 📬 Endpoints

| Method | Endpoint             | Description         |
|--------|----------------------|---------------------|
| GET    | /api/books           | Get all books       |
| GET    | /api/books/:id       | Get book by ID      |
| POST   | /api/books           | Add new book        |
| PUT    | /api/books/:id       | Update book         |
| DELETE | /api/books/:id       | Delete book         |

### ✅ Example JSON (for POST/PUT)
```json
{
  "title": "New Book Title",
  "author": "Author Name"
}
```